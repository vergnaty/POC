﻿(function () {
    'use strict';
    angular
        .module('gcmpApp')
        .controller("indexCtrl", ['$scope', '$http', '$rootScope', '$location', indexCtrl]);

    /***********************************
    *       Index Controller
    *    Manage introduction Page
    ************************************/
    function indexCtrl($scope, $http, $rootScope, $location) {

        $scope.searchModel = { FullText: "", Paging: { PageNumber: 1, PageSize: 10 }, Filters: [], Aggregations: [] };
        $scope.dellPurchaseOrders = [];
        $scope.pagings = [10, 25, 50, 100];
        $scope.totalItems = 0;
        $scope.aggregations = [];
        $scope.showJsonCode = false;
        $scope.currentUrl = url + "search/fulltext";

        $scope.jsonData = [];
        $scope.aggregationTypes = ["Term", "Sum", "Avg"];

        $scope.fields = [{ key: "DPID", desc: "Purchase ID" },
                          { key: "PurchaseStatus", desc: "Purchase status" },
                          { key: "PONumber", desc: "PO number" },
                          { key: "OrderType", desc: "Order type" },
                          { key: "CreatedBy", desc: "Created By" },
                          { key: "BusinessContext.CompanyNumber", desc: "Company number" },
                          { key: "BusinessContext.AccessGroup", desc: "Access group" },
                          { key: "BusinessContext.BusinessUnitId", desc: "Business unit ID" },
                          { key: "BusinessContext.Country", desc: "Country" },
                          { key: "BusinessContext.BrowserIP", desc: "Browser IP" },
                          { key: "BusinessContext.ChannelID", desc: "Channal ID" },
                          { key: "BusinessContext.Culture", desc: "Culture" },
                          { key: "BusinessContext.OriginalSourceApplicationName", desc: "Original App name" },
                          { key: "BusinessContext.DepartmentCode", desc: "Department code" },
                          { key: "BusinessContext.SourceApplicationName", desc: "Source App name" },
                          { key: "BusinessContext.DestinationSystem", desc: "Destination system" },
                          { key: "BusinessContext.Segment", desc: "Segment" },
                          { key: "PaymentMethods.PaymentType", desc: "Payment type" },
                          { key: "Items.OrderLines.Status", desc: "Order status" },
                          { key: "Orders.FUID", desc: "FUID" },
                          { key: "Orders.OrderStatus", desc: "Order status" }];

        $scope.operations = ["Equals", "DoesNotEqual", "GreaterThan", "LessThan", "StartsWith", "EndsWith", "Contains", "DoesNotContain"];
        $scope.conditions = ["AND", "OR"];

        $scope.search = search;
        $scope.showDetails = showDetails;
        $scope.setPagination = setPagination;
        $scope.addFilter = addFilter;
        $scope.removeFilter = removeFilter;
        $scope.addAggregation = addAggregation;
        $scope.removeAggregation = removeAggregation;
        $scope.showJsonRequest = showJsonRequest;

        function search() {
            $http.post(url + "search/fulltext", $scope.searchModel).then(function (response) {
                $scope.dellPurchaseOrders = response.data.Data.Documents;
                $scope.totalItems = response.data.TotalRecords;

                if (response.data.Data.Aggregations.length > 0) {
                    buildChart(response.data.Data.Aggregations[0]);
                    $scope.aggregations = response.data.Data.Aggregations;

                    if (response.data.Data.Aggregations.length > 1) {
                        buildPieChart(response.data.Data.Aggregations[1]);
                    }
                }

                console.log(response.data.Data);
            }, function (error) {
            });
        }

        function addFilter() {
            $scope.searchModel.Filters.push({ Name: "", Value: "", Condition: "AND", Operation: "Equals" });
        }

        function addAggregation() {
            $scope.searchModel.Aggregations.push({ Name: "", Type: "Term", Size: 10 });
        }

        function showDetails(item) {
            $scope.dellPurchaseOrders.forEach(function (ele) {
                if (ele.DPID == item.DPID) {
                    ele.showDetails = item.showDetails == true ? false : true;
                }
                else
                    ele.showDetails = false;
            });
        }

        function removeFilter(index) {
            $scope.searchModel.Filters.splice(index, 1);
        }

        function removeAggregation(index) {
            $scope.searchModel.Aggregations.splice(index, 1);
        }

        function setPagination(value) {
            $scope.searchModel.Paging.PageSize = value;
            $scope.searchModel.Paging.PageNumber = 1;
            search();
        }

        function showJsonRequest() {
            $scope.showJsonCode = !$scope.showJsonCode;
        }

        search();


        function buildChart(item) {
            console.log(item);

            var chart = Highcharts.chart('container1', {
                title: {
                    text: item.Key
                },
                subtitle: {
                    text: 'Plain'
                },
                xAxis: {
                    categories: (function () {
                        var categories = [];
                        for (var i = 0; i < item.Children.length; i++) {
                            categories.push(item.Children[i].Key)
                        }
                        return categories;
                    })()
                },
                series: [{
                    type: 'column',
                    colorByPoint: true,
                    data: (function () {
                        var data = [];
                        for (var i = 0; i < item.Children.length; i++) {
                            data.push(item.Children[i].Count);
                        }
                        return data;
                    })(),
                    showInLegend: false
                }]

            });
        }


        function buildPieChart(item) {
            console.log(item);
            Highcharts.chart('container2', {
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie'
                },
                title: {
                    text: item.Key
                },
                tooltip: {
                    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                            style: {
                                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                            }
                        }
                    }
                },
                series: [{
                    name: 'Brands',
                    colorByPoint: true,
                    data: (function () {
                        var data = [];
                        for (var i = 0; i < item.Children.length; i++) {
                            data.push({ name: item.Children[i].Key, y: item.Children[i].Count });
                        }
                        return data;
                    })()
                }]
            });
        }

    }
})();