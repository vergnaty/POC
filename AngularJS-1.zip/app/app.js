﻿var gcmpApp = angular.module("gcmpApp", ["ngRoute", "ui.bootstrap", "jsonFormatter", "ngclipboard"]);

gcmpApp.config("$routeProvider", "$httpProvider",
  function ($routeProvider, $httpProvider) {

      $routeProvider.
          when("/odm", {
              templateUrl: "views/odm/dellPurchase.html",
              controller: "indexCtrl"
          }).
        when("/swagger", {
            templateUrl: "views/odm/swaggerDoc.html"
        }).
        //when("/signup", {
        //    templateUrl: "app/views/signup.html?d=" + new Date(),
        //    controller: "signupCtrl"
        //}).
        otherwise({
            redirectTo: "/odm"
        });
  });